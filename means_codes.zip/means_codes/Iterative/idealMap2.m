function [ma] = idealMap2(D,n)
%IDEALMAP2(D,n) returns a cycle used in the MeanIterativeCheap function.
%The cycle is built with a greedy algorithm is order to try to maximize its length, 
%similarly as in [1].
%D is a vector containing the lengths of the edges (which are usually the 
%distances between vectors recording the past communication of the nodes)
%and n is the number of nodes.
%ma is a permutation of the nodes corresponding to the cycle returned

%References : 
%[1] Mikl�s P�lfia. The riemann barycenter computation and means of several matrices.
%Int. J. Comput. Math. Sci, 3(3):128�133, 2009.e C

d = length(D);
i = 1;
j = 2;
r = zeros(d,3);
r(:,1) = D;
ma = zeros(n,1);

for k = 1:d
    r(k,2) = i;
    r(k,3) = j;
    if j == n
        i = i+1;
        j = i+1;
    else
        j = j+1;
    end
end

[R,I] = sort(r(:,1),'descend');

r = r(I,:);
ma(1) = r(1,2);
j = r(1,3);
I2 = (r(:,2)== ma(1));
r(I2,:) = [];
I3 = (r(:,3)== ma(1));
r(I3,:) = [];


for k = 2:n-1
    indx = find((r(:,2)==j | r(:,3)==j),1);
    if r(indx,2) == j
        j = r(indx,3);
        ma(k) = r(indx,2);
    else 
        j = r(indx,2);
        ma(k) = r(indx,3);
    end
    I2 = (r(:,2)== ma(k));
    r(I2,:) = [];
    I3 = (r(:,3)== ma(k));
    r(I3,:) = [];
end
ma(n) = j;


end