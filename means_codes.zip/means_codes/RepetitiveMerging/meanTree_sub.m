function [ A ] = meanTree_sub( A )
%MEANTREE_SUB(A) estimates the Karcher mean using the Tree merging algorithm.
%This algorithm consists in merging successively the matrices, until there
%is only one matrix left. The pair of matrices merged are chosen according
%to an upside down tree pattern.

%A is a 3D array containing the matrices whose mean has to be estimated
%along the third dimension
%A is the estimation of the Karcher mean

[m,~,n] = size(A);
k = floor(log2(n));
nStar = 2^k;
count = 0;

%preprocessing step
if(nStar ~= n)
    l = n-nStar;
    indx = randperm(n);
    w = zeros(1,nStar);
    B = zeros(m,m,nStar);
    
    for i = 1:l                     
        i1 = indx(2*i-1);
        i2 = indx(2*i);
        w(i) = 2;
        B(:,:,i) = MGeom(A(:,:,i1),A(:,:,i2),0.5);
        count = count + 1;
    end
    
    indx = indx(2*l+1:end);
    for i = l+1:nStar               
        i1 = indx(i-l);
        B(:,:,i) = A(:,:,i1);
        w(i) = 1;
    end
    
    A = B;
else 
    w = ones(1,n);
end
%end of the preprocessing step


i = k;

while i>0
    
    nCur = 2^(i);
    nNew = 2^(i-1);
    B = zeros(m,m,nNew);
    indx = randperm(nCur);
    wnew = zeros(1,nNew);
    
   for j = 1:nNew
       i1 = indx(2*j-1);
       i2 = indx(2*j);
       s = w(i1)+w(i2);
       wcur = w(i2)/s;
       wnew(j) = s;
       B(:,:,j) = MGeom(A(:,:,i1), A(:,:,i2),wcur);
       count = count+1;
   end
   
   A = B;
   w = wnew;
   i = i-1;
   
end

end