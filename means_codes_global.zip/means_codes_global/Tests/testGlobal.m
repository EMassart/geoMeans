function [] = testGlobal( str )
%Gives an overview of the global performances of the different algorithms.
%n = number of matrices per set
%m = size of the matrices
% WARNING : the execution of this code may take a few hours.

n = 5;     %number of matrices in each set
k = 1000   %number of sets used in the test
m = 10;     %size of the matrices

list_of_methods = {'cheap','meanStar','meanCycle','meanHarmonic','meanArithmetic','Crude','CrudeImproved','meanIterativeRandom','meanIterativeIdealMap',...
    'meanRandomReduce','meanDistMinReduce','meanDistMaxReduce','meanTree','meanProgressExpansion','CrudeIterative','meanIterativeIdealMapCheap'};

%preallocation
for i = 1:length(list_of_methods)                                       
    eval(['tTot' num2str(i) ' = zeros(1,k);'])
    eval(['dist' num2str(i) ' = zeros(1,k);'])
end

d_ref = zeros(1,k);

for indx = 1:k
    fprintf('Set number %d\n',indx);
    A = zeros(m,m,n);
    Acell = cell(1,n);
    for jLoc = 1:n
        A(:,:,jLoc) = defPos4(m);
        Acell{jLoc} = A(:,:,jLoc);
    end
    [meanKarcher,~ ] = karcher_sd_spd(sum(A,3)./n,'approx2',Acell);
   %runs the methods and computes the distance between the solution
   %returned and the Karcher mean computed with a steepest descent
   %algorithm
    for i = 1:length(list_of_methods)                                     
        eval(['[M',num2str(i),',tTot',num2str(i),'(indx)] = ',list_of_methods{i}, '( A );'])
        eval(['dist', num2str(i) ,'(indx) = dist(M',num2str(i), ',meanKarcher);'])
    end
    d_ref(indx) = dist(A(:,:,1),meanKarcher);    
end

%averages the values obtained over the sets
for i = 1:length(list_of_methods)
    eval(['distM', num2str(i) ,' = mean(dist',num2str(i), './d_ref);'])
    eval(['tTotM', num2str(i) ,' = mean(tTot',num2str(i), ');'])
end

save(str);


%plots
figure;
hold on;
plot(tTotM1,distM1,'*b',tTotM4,distM4,'*m',tTotM5,distM5,'*k',tTotM10,distM10,'ob',tTotM11,distM11,'om',tTotM12,distM12,'og',...
    tTotM13,distM13,'dk',tTotM14,distM14,'dm',tTotM8,distM8,'sr',tTotM9,distM9,'sg',tTotM16,distM16,'sk',tTotM2,distM2,'*r',tTotM3,distM3,'*g',...
    tTotM6,distM6,'^b',tTotM7,distM7,'^k',tTotM15,distM15,'^r');
xlabel('CPU time');
ylabel('Error E_{rel}');
legend('Cheap','Harmonic','Arithmetic','Random','DistMin','DistMax','Tree','ProgressiveExpansion',...
'Iterative Random','Iterative IdealMap','Iterative IdealMap Cheap','Star','Cycle','Crude','CrudeImproved','A-H Random','Location','EastOutside');
axis([-0.005 0.06 -0.1 1.3]);

% additive axes
vert = graph2d.constantline(0, 'LineStyle',':', 'Color',[.5 .5 .5]);
changedependvar(vert,'x');
hori = graph2d.constantline(0, 'LineStyle',':', 'Color',[.5 .5 .5]);
changedependvar(hori,'y');

%plot number 2 : zoom 
figure;
hold on;
plot(tTotM1,distM1,'*b',tTotM10,distM10,'ob',tTotM11,distM11,'om',tTotM12,distM12,'og',...
    tTotM13,distM13,'dk',tTotM14,distM14,'dm',tTotM8,distM8,'sr',tTotM9,distM9,'sg',tTotM16,distM16,'sk',tTotM2,distM2,'*r',tTotM3,distM3,'*g',...
    tTotM7,distM7,'^k',tTotM15,distM15,'^r');
xlabel('CPU time');
ylabel('Error E_{rel}');
legend('Cheap','Random','DistMin','DistMax','Tree','ProgressiveExpansion',...
'Iterative Random','Iterative IdealMap','Iterative IdealMap Cheap','Star','Cycle','CrudeImproved','A-H Random','Location','EastOutside');
axis([-0.005 0.06 -0.01 0.2]);

% additive axes
vert = graph2d.constantline(0, 'LineStyle',':', 'Color',[.5 .5 .5]);
changedependvar(vert,'x');
hori = graph2d.constantline(0, 'LineStyle',':', 'Color',[.5 .5 .5]);
changedependvar(hori,'y');

end