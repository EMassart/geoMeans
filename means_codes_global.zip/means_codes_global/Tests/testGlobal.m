function [] = testGlobal( str )
%Gives an overview of the global performances of the different algorithms.
%n = number of matrices per set
%m = size of the matrices
% WARNING : the execution of this code may take a few hours.

n = 5;     %number of matrices in each set
k = 1000;    %number of sets used in the test
m = 10;     %size of the matrices

tTot1 = zeros(1,k);
tTot2 = zeros(1,k);
tTot3 = zeros(1,k);
tTot4 = zeros(1,k);
tTot5 = zeros(1,k);
tTot6 = zeros(1,k);
tTot7 = zeros(1,k);
tTot8 = zeros(1,k);
tTot9 = zeros(1,k);
tTot10 = zeros(1,k);
tTot11 = zeros(1,k);
tTot12 = zeros(1,k);
tTot13 = zeros(1,k);
tTot14 = zeros(1,k);
tTot15 = zeros(1,k);
tTot16 = zeros(1,k);

dist1 = zeros(1,k);
dist2 = zeros(1,k);
dist3 = zeros(1,k);
dist4 = zeros(1,k);
dist5 = zeros(1,k);
dist6 = zeros(1,k);
dist7 = zeros(1,k);
dist8 = zeros(1,k);
dist9 = zeros(1,k);
dist10 = zeros(1,k);
dist11 = zeros(1,k);
dist12 = zeros(1,k);
dist13 = zeros(1,k);
dist14 = zeros(1,k);
dist15 = zeros(1,k);
dist16 = zeros(1,k);

d_ref = zeros(1,k);

for indx = 1:k
    fprintf('Set number %d\n',indx);
    A = zeros(m,m,n);
    Acell = cell(1,n);
    for jLoc = 1:n
        A(:,:,jLoc) = defPos4(m);
        Acell{jLoc} = A(:,:,jLoc);
    end
    [meanKarcher,~ ] = karcher_sd_spd(sum(A,3)./n,'approx2',Acell);
    
    [ M1, tTot1(indx)] = cheap(Acell{1:end});
    [ M2, tTot2(indx)] = meanStar( A );
    [ M3, tTot3(indx)] = meanCycle( A );
    [ M4, tTot4(indx)] = meanHarmonic( A );
    [ M5, tTot5(indx)] = meanArithmetic( A );
    [ M6, tTot6(indx)] = Crude( A);
    [ M7, tTot7(indx)] = CrudeImproved(A,2);
    [ M8, tTot8(indx)] = meanIterativeRandom( A );
    [ M9, tTot9(indx)] = meanIterativeIdealMap( A );
    [ M10, tTot10(indx)] = meanRandomReduce( A );
    [ M11, tTot11(indx)] = meanDistMinReduce( A );
    [ M12, tTot12(indx)] = meanDistMaxReduce( A );
    [ M13, tTot13(indx)] = meanTree( A,1);
    [ M14, tTot14(indx)] = meanProgressExpansion( A,1);
    [ M15, tTot15(indx)] = CrudeIterative( A );
    [ M16, tTot16(indx)] = meanIterativeIdealMapCheap( A );
    
    [dist1(indx)] = dist(M1,meanKarcher);
    [dist2(indx)] = dist(M2,meanKarcher);
    [dist3(indx)] = dist(M3,meanKarcher);
    [dist4(indx)] = dist(M4,meanKarcher);
    [dist5(indx)] = dist(M5,meanKarcher);
    [dist6(indx)] = dist(M6,meanKarcher);
    [dist7(indx)] = dist(M7,meanKarcher);
    [dist8(indx)] = dist(M8,meanKarcher);
    [dist9(indx)] = dist(M9,meanKarcher);
    [dist10(indx)] = dist(M10,meanKarcher);
    [dist11(indx)] = dist(M11,meanKarcher);
    [dist12(indx)] = dist(M12,meanKarcher);
    [dist13(indx)] = dist(M13,meanKarcher);
    [dist14(indx)] = dist(M14,meanKarcher);
    [dist15(indx)] = dist(M15,meanKarcher);
    [dist16(indx)] = dist(M16,meanKarcher);
    
    d_ref(indx) = dist(A(:,:,1),meanKarcher);
    
end

distM1 = mean(dist1./d_ref);
distM2 = mean(dist2./d_ref);
distM3 = mean(dist3./d_ref);
distM4 = mean(dist4./d_ref);
distM5 = mean(dist5./d_ref);
distM6 = mean(dist6./d_ref);
distM7 = mean(dist7./d_ref);
distM8 = mean(dist8./d_ref);
distM9 = mean(dist9./d_ref);
distM10 = mean(dist10./d_ref);
distM11 = mean(dist11./d_ref);
distM12 = mean(dist12./d_ref);
distM13 = mean(dist13./d_ref);
distM14 = mean(dist14./d_ref);
distM15 = mean(dist15./d_ref);
distM16 = mean(dist16./d_ref);


tTotM1 = mean(tTot1);
tTotM2 = mean(tTot2);
tTotM3 = mean(tTot3);
tTotM4 = mean(tTot4);
tTotM5 = mean(tTot5);
tTotM6 = mean(tTot6);
tTotM7 = mean(tTot7);
tTotM8 = mean(tTot8);
tTotM9 = mean(tTot9);
tTotM10 = mean(tTot10);
tTotM11 = mean(tTot11);
tTotM12 = mean(tTot12);
tTotM13 = mean(tTot13);
tTotM14 = mean(tTot14);
tTotM15 = mean(tTot15);
tTotM16 = mean(tTot16);

save(str);

figure;
hold on;
plot(tTotM1,distM1,'*b',tTotM4,distM4,'*m',tTotM5,distM5,'*k',tTotM10,distM10,'ob',tTotM11,distM11,'om',tTotM12,distM12,'og',...
    tTotM13,distM13,'dk',tTotM14,distM14,'dm',tTotM8,distM8,'sr',tTotM9,distM9,'sg',tTotM16,distM16,'sk',tTotM2,distM2,'*r',tTotM3,distM3,'*g',...
    tTotM6,distM6,'^b',tTotM7,distM7,'^k',tTotM15,distM15,'^r');
xlabel('CPU time');
ylabel('Error E_{rel}');
legend('Cheap','Harmonic','Arithmetic','Random','DistMin','DistMax','Tree','ProgressiveExpansion',...
'Iterative Random','Iterative IdealMap','Iterative IdealMap Cheap','Star','Cycle','Crude','CrudeImproved','A-H Random','Location','EastOutside');
axis([-0.005 0.06 -0.1 1.3]);

% additive axes
vert = graph2d.constantline(0, 'LineStyle',':', 'Color',[.5 .5 .5]);
changedependvar(vert,'x');
hori = graph2d.constantline(0, 'LineStyle',':', 'Color',[.5 .5 .5]);
changedependvar(hori,'y');

figure;
hold on;
plot(tTotM1,distM1,'*b',tTotM10,distM10,'ob',tTotM11,distM11,'om',tTotM12,distM12,'og',...
    tTotM13,distM13,'dk',tTotM14,distM14,'dm',tTotM8,distM8,'sr',tTotM9,distM9,'sg',tTotM16,distM16,'sk',tTotM2,distM2,'*r',tTotM3,distM3,'*g',...
    tTotM7,distM7,'^k',tTotM15,distM15,'^r');
xlabel('CPU time');
ylabel('Error E_{rel}');
legend('Cheap','Random','DistMin','DistMax','Tree','ProgressiveExpansion',...
'Iterative Random','Iterative IdealMap','Iterative IdealMap Cheap','Star','Cycle','CrudeImproved','A-H Random','Location','EastOutside');
axis([-0.005 0.06 -0.01 0.2]);

% additive axes
vert = graph2d.constantline(0, 'LineStyle',':', 'Color',[.5 .5 .5]);
changedependvar(vert,'x');
hori = graph2d.constantline(0, 'LineStyle',':', 'Color',[.5 .5 .5]);
changedependvar(hori,'y');

end