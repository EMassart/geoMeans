function [M_res,tTot] = CrudeImproved(A,n_cl)
%CRUDEIMPROVED(A,n_cl) : Adaptation of the Crude mean that was proposed in [1]
%to get a more accurate estimation of the Karcher mean by splitting
%the input matrices into sets regarding their condition number.
%A is a 3D array containing the matrices whose mean has to be estimated
%along the third dimension
%M_res is the estimation of the Karcher mean and tTot is the CPU time used by the function

%References : 
%[1] Ben Jeuris and Raf Vandebril. Geometric mean algorithms based on harmonic and
%arithmetic iterations. In Geometric Science of Information, pages 785�793. Springer,
%2013.

tStart = cputime;
[m,~,n] = size(A);
lco = zeros(n,1);
for i = 1:n
    lco(i) = log10(cond(A(:,:,i)));
end

lcoRange = linspace(0,8,n_cl+1);
ind = 0;  
sum_indices = 0;
M = zeros(m,m,n);
w = zeros(1,n);
X0 = zeros(m,m);
for i = 2:length(lcoRange)
    if i<length(lcoRange)
        indices = find(lco >= lcoRange(i-1) & lco < lcoRange(i));
    else 
        indices = find(lco >= lcoRange(i-1));
    end
        
    if ~isempty(indices)
        ind = ind + 1;
        M(:,:,ind) =  Crude( A(:,:,indices));
        w(ind) = length(indices);
        X0 = X0 + w(ind)*M(:,:,ind);
    end
    sum_indices = sum_indices + length(indices);
end

% X0 = X0./sum(w);
M = M(:,:,1:ind);
w = w(1:ind);

if ind==2
    M_res = MGeom(M(:,:,1),M(:,:,2),w(2)/(w(1)+w(2)));
else
    [ M_res,~] = meanDistMaxReduce( M );
%or with the Karcher mean to perform the last step (considerably more costly!)
%     MCell = cell(1,length(w));
%     for j = 1:length(w);
%         MCell{j} = M(:,:,j);
%     end
%     [ M_res,~ ] = karcher_sd_spd(X0,'approx2',MCell,w);
end
    
tTot = cputime-tStart;

end
